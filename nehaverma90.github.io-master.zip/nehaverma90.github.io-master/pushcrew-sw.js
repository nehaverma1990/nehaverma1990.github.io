var version = 6;
importScripts('https://cdn.pushcrew.com/sw/b2cf4395516ec5ace2c898428f211358.js');